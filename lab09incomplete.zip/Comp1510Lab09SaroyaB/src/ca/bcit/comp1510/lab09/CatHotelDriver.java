/**
 * 
 */
package ca.bcit.comp1510.lab09;

import java.util.Random;

/**
 * @author saroy
 *
 */
public class CatHotelDriver {

    /**
     * @param args
     */
    public static void main(String[] args) {
        CatHotel testHotel = new CatHotel("Test Hotel");
        
        Random randnum = new Random();
        
        Cat cat1 = new Cat(2, "TestCat1");
        Cat cat2 = new Cat(3, "TestCat2");
        
        
    }

}
